# Location to create and store customer specific folders and Modules

## Audience
Developers, Solution Architects, Technical Architects, Delivery Consultants

## Notes

* You must store the Modules, state file and variables for each customer in this location. Separate from the standard templates.
* This is so that we have a record of terraform deployments for each customer and can easily see the state that was deployed.   


