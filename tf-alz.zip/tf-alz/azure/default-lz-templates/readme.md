Who is working on what modules 11/06/21

Will
- Blueprints call up tf modules

Thomas
- Log analytics
- Automation account

Russell
- network
- gateway

Need to have test sub to test deployments.